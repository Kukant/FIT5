/**
 * Autor: Tomas Kukan, xkukan00@stud.fit.vutbr.cz
 * Autorsky podil: priblizne 95% - vse krom prazdnych funkci a casti funkce main()
 * Datum: 19. 12. 2018
**/

#include <fitkitlib.h>
#include <keyboard/keyboard.h>
#include <lcd/display.h>
#include <string.h>

// periody pro urcite tony
// T = AFREQ/f
#define A5 37
#define B5 33
#define C6 31
#define C5 61 // H
#define D5 56
#define E5 50
#define F5 47
#define G5 42
#define G6 20
#define F7 11

#define AFREQ 32768

#define SOUND BIT0

long count = 0;
long currentTonePeriod = 0;
long currentToneFrequency = 0;
long frequency;
int playing_tone = 0;
char tone = 0;
int wait = 0;

void print_user_help(void) {}

void play_tone(long toneP) {
  if (playing_tone) {
     return;
  }
  playing_tone = 1;
  TACTL = TASSEL_1 + MC_2;
  TAR = 0x0000;
  CCR0 = toneP;
  currentTonePeriod = toneP;
  currentToneFrequency = AFREQ/toneP;
}

interrupt (TIMERA0_VECTOR) Timer_A(void) { 
  if (playing_tone) {
    P6OUT ^= SOUND;
    CCR0 += currentTonePeriod;
  }
}

void play_song(char* notes) {
  int i = 0;
  int c;
  while (c = notes[i++]) {
    switch (c) {
      case 'A': play_tone(A5); break;
      case 'B': play_tone(B5); break;
      case 'C': play_tone(C6); break;
      case 'D': play_tone(D5); break;
      case 'E': play_tone(E5); break;
      case 'F': play_tone(F5); break;
      case 'G': play_tone(G5); break;
      case 'H': play_tone(C5); break;
      default: break;
    }
    delay_ms(510);
    playing_tone = 0;
  }
}

/*******************************************************************************
 * Obsluha klavesnice
*******************************************************************************/
int keyboard_idle()
{
    char ch = key_decode(read_word_keyboard_4x4());
    LCD_clear();
    if (ch != 0) {
      switch (ch)
      {
        case 'A':
	  play_song("HEGHEGEEDEFDEEDEFDEDH");	
        break;

        case 'B':
	  play_song("GABCCCCBABBBBAGAAAABAGGG");
        break;

	case '1':
	 play_tone(B5);
         LCD_append_char('B');
        break;

        case '2':
	 play_tone(C5);
         LCD_append_char('C');
        break;

        case '3':
	 play_tone(D5);
         LCD_append_char('D');
        break;

        case '4':
	 play_tone(E5);
         LCD_append_char('E');
        break;

        case '5':
	 play_tone(F5);	
         LCD_append_char('F');
        break;

        case '6':
	 play_tone(G5);	
         LCD_append_char('G');
        break;

        case '7':
	 play_tone(C6);	 
         LCD_append_char('A');
        break;

        case '8':
	play_tone(G6);
        LCD_append_char('B');
        break;

        case '9':
	play_tone(F7);
        LCD_append_char('C');
        break;

        default:
        LCD_append_char('!');
	playing_tone = 0;
        break;

      }    
    } else {
      // waiting for the user to move finger up 
      if (wait++ > 5) {
      	wait = 0;
	playing_tone = 0;
      }
    }
  return 0;
}



/*******************************************************************************
 * Dekodovani a vykonani uzivatelskych prikazu
*******************************************************************************/
unsigned char decode_user_cmd(char *cmd_ucase, char *cmd)
{
  return CMD_UNKNOWN;
}

/*******************************************************************************
 * Inicializace periferii/komponent po naprogramovani FPGA
*******************************************************************************/
void fpga_initialized() {}

/*******************************************************************************
 * Hlavni funkce
*******************************************************************************/
int main(void)
{
  CCTL0 = CCIE; // povol preruseni od casovace
  TACTL = MC_0;

  initialize_hardware();
  keyboard_init();

  P6DIR |= SOUND;\
  P6OUT = P6OUT & ~SOUND;
  while (1)
  {
    delay_ms(10);
    keyboard_idle();                   // obsluha klavesnice
    terminal_idle();                   // obsluha terminalu
  }         
}

